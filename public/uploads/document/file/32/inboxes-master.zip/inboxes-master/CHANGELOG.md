* 0.2.2 Bugfix #11, #16, #18, #15, #13, improved tests. `unread_for?(user)` method for messages added
* 0.2.1 RSpec test suite added.
* 0.2 #9 Added ability to attach discussion to any other model (discussable). Don't forget to update the database with upgrade migration (read more above in readme)!
* 0.1.1-0.1.5 Cancan ability logic changes, a lot of small fixes
* 0.1.0 Initial version