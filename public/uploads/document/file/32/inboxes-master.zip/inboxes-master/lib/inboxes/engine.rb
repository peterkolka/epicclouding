module Inboxes
  class Engine < ::Rails::Engine
  end
end